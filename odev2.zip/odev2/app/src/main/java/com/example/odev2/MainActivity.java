package com.example.odev2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lvFilmler;
    ArrayList<FilmTurleri> filmTurleriList;

    ArrayList<FilmDetay> filmDetayList;
    Intent intent;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lvFilmler = findViewById(R.id.lv_filmler);
        generateFilms();

        FilmTurleriAdapter filmTurleriAdapter = new FilmTurleriAdapter(this, filmTurleriList);

        lvFilmler.setAdapter(filmTurleriAdapter);

        lvFilmler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                intent = new Intent(MainActivity.this, SecondActivity.class);
                bundle = new Bundle();
                bundle.putParcelableArrayList("filmler", filmDetayList);
                intent.putExtras(bundle);
                startActivity(intent);


            }
        });
    }


    public void generateFilms() {
        filmTurleriList = new ArrayList<>();
        FilmTurleri filmTurleri1 = new FilmTurleri(R.drawable.ic_launcher_background, "Mustafa");
        FilmTurleri filmTurleri2 = new FilmTurleri(R.drawable.ic_launcher_background, "Mustafa");
        FilmTurleri filmTurleri3 = new FilmTurleri(R.drawable.ic_launcher_background, "Mustafa");
        FilmTurleri filmTurleri4 = new FilmTurleri(R.drawable.ic_launcher_background, "Mustafa");

        filmTurleriList.add(filmTurleri1);
        filmTurleriList.add(filmTurleri2);
        filmTurleriList.add(filmTurleri3);
        filmTurleriList.add(filmTurleri4);

        filmDetayList = new ArrayList<>();

        FilmDetay filmDetay1 = new FilmDetay(R.drawable.therevenant, "REVENANT", "Alejandro González Iñárritu", "LEONARDO DICAPRIO, TOM HARDY", "9.6");
        FilmDetay filmDetay2 = new FilmDetay(R.drawable.intime, "IN TIME", "Andrew Niccol", "JUSTIN TIMBERLAKE, AMANDA SEYFRIED", "7.0");
        FilmDetay filmDetay3 = new FilmDetay(R.drawable.titanic, "TITANIC", "James Cameron", "LEONARDO DICAPRIO, KATE WINSLET", "10.0");
        FilmDetay filmDetay4 = new FilmDetay(R.drawable.terminator, "TERMINATOR", "ALON TAYLOR", "Arnold schwarzenegger, Emillia Clarke", "8.2");
        FilmDetay filmDetay5 = new FilmDetay(R.drawable.mynameiskhan, "My Name Is Khan", "Karan Johar", "shakib khan, kajol, Jimmy Shergill, arjan aujla", "9.1");

        filmDetayList.add(filmDetay1);
        filmDetayList.add(filmDetay2);
        filmDetayList.add(filmDetay3);
        filmDetayList.add(filmDetay4);
        filmDetayList.add(filmDetay5);
    }
}
