package com.example.odev2;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class FilmTurleriAdapter extends BaseAdapter {

    ArrayList<FilmTurleri> filmTurleriList;
    private LayoutInflater mInflater;


    public FilmTurleriAdapter(Activity activity, ArrayList<FilmTurleri> filmTurleriList) {

        this.mInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.filmTurleriList = filmTurleriList;
    }

    @Override
    public int getCount() {
        return filmTurleriList.size();
    }

    @Override
    public Object getItem(int i) {
        return filmTurleriList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = mInflater.inflate(R.layout.film_turler, null);

        ImageView ivFilmTur = view.findViewById(R.id.iv_film_tur);
        TextView tvFilmAd = view.findViewById(R.id.tv_film_ad);
        LinearLayout linearLayout = view.findViewById(R.id.sub_lineer);

        if (i % 2 == 0) {
            linearLayout.setBackgroundResource(R.color.softGray);
        }

        FilmTurleri filmTurleri = filmTurleriList.get(i);

        ivFilmTur.setImageResource(filmTurleri.getImgId());
        tvFilmAd.setText(filmTurleri.getName());


        return view;
    }
}
