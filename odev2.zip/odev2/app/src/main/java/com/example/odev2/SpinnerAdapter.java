package com.example.odev2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class SpinnerAdapter extends ArrayAdapter<FilmDetay> {

    Context context;
    ArrayList<FilmDetay> filmDetayList;

    public SpinnerAdapter(@NonNull Context context, int resource, @NonNull ArrayList<FilmDetay> filmDetayList) {
        super(context, resource, (List<FilmDetay>) filmDetayList);
        this.context = context;
        this.filmDetayList = filmDetayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.filmler_spinner, parent, false);
        ImageView ivFilmPhoto = view.findViewById(R.id.iv_film_photoo);
        TextView tvFilmName = view.findViewById(R.id.tv_film_namee);

        FilmDetay filmDetay = filmDetayList.get(position);

        ivFilmPhoto.setImageResource(filmDetay.getFilmId());
        tvFilmName.setText(filmDetay.getFilmAd());

        return view;


    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.filmler_spinner, parent, false);
        ImageView ivFilmPhoto = view.findViewById(R.id.iv_film_photoo);
        TextView tvFilmName = view.findViewById(R.id.tv_film_namee);
        LinearLayout linearLayout = view.findViewById(R.id.film_lineer);
        if (position % 2 == 0) {
            linearLayout.setBackgroundResource(R.color.softGray);

        }

        FilmDetay filmDetay = filmDetayList.get(position);

        ivFilmPhoto.setImageResource(filmDetay.getFilmId());
        tvFilmName.setText(filmDetay.getFilmAd());

        return view;
    }
}
